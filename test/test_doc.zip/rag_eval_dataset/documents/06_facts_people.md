# Reference Facts — People

Dr. Mira Sen joined NRL in 2019 and became director in 2024. Her research area is trustworthy AI.

Priya Nair leads Retrieval Systems. She designed the original Aurora hybrid retrieval prototype in 2021.

Daniel Okafor leads Operations. He owns the quarterly document review process.

Elena Rossi is a senior systems engineer focused on indexing infrastructure. She joined in 2022.

Marcus Lee is a research engineer in Human Factors. He maintains the usability benchmark.

Names are intentionally repeated across documents so retrieval systems can be tested for entity disambiguation.
