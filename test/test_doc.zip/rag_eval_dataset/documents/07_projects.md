# Current Projects

## Project Lantern
Lantern is a document-grounding benchmark. It measures whether an assistant can distinguish supported claims from plausible but unsupported claims. Its benchmark owner is Marcus Lee.

## Project Cedar
Cedar is an indexing reliability project. Its goal is to reduce failed ingestion jobs. Elena Rossi is the technical owner. Cedar uses the `embedding_failed` queue described in the ingestion standard.

## Project Iris
Iris studies prompt-injection resistance in retrieval systems. Priya Nair is the technical lead, while Daniel Okafor coordinates operational reviews.

## Project Kestrel
Kestrel is a discontinued 2023 prototype for image-heavy PDF retrieval. It used OCR confidence threshold 0.75. This value belongs only to Kestrel and must not be confused with the current ingestion standard's threshold of 0.82.
