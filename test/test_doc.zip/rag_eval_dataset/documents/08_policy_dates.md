# Policy Timeline

2018 — Northstar Research Lab was founded.

2021 — Priya Nair designed the original Aurora hybrid retrieval prototype.

2023 — Kestrel image-PDF prototype used an OCR confidence threshold of 0.75.

2024 — Dr. Mira Sen became NRL director.

2025 — Aurora 3.1 used weighted score addition for merging retrieval scores.

2026 — Aurora 3.2 became the reference production version and introduced reciprocal-rank fusion.

The 2023 Kestrel threshold and the 2026 ingestion threshold are intentionally different historical facts.
