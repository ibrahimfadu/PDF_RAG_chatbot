# Northstar Research Lab — Organization Overview

Northstar Research Lab (NRL) is a fictional interdisciplinary research organization founded in 2018. Its headquarters are in Bengaluru, with satellite teams in Pune and Hyderabad. The lab studies trustworthy AI, information retrieval, distributed systems, and human-computer interaction.

The current director is Dr. Mira Sen. The operations lead is Daniel Okafor, and the retrieval group is led by Priya Nair. NRL's public research program is divided into four groups: Retrieval Systems, Applied ML, Systems Engineering, and Human Factors.

The lab's internal document identifier prefix is NRL-DOC. Documents are reviewed quarterly. A document marked "approved" may be used for operational decisions; a document marked "draft" is informational only.

Important distinction: Northstar Research Lab is fictional and unrelated to any real organization with a similar name.
