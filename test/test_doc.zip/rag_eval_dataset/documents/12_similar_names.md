# Similar Entity Stress Test

There are several intentionally similar names in the corpus.

Mira Sen — director of Northstar Research Lab.
Mira Shah — an external consultant mentioned only in this file.
Priya Nair — Retrieval Systems lead.
Priya Nairam — a fictional vendor contact mentioned only in this file.
Aurora 3.2 — current retrieval platform version.
Aurora 3.1 — previous retrieval platform version.
Kestrel — discontinued image-PDF prototype.

Do not merge similar names merely because their strings overlap.
